#ifndef IRICLIB_COMBINE_H
#define IRICLIB_COMBINE_H

#include "iriclib_global.h"

#ifdef __cplusplus
extern "C" {
#endif

int IRICLIBDLL cg_iRIC_Combine_Solutions(int fid, int* progress);

#ifdef __cplusplus
}
#endif

#endif // IRICLIB_COMBINE_H
